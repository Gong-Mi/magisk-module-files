#!/system/bin/sh
# Read-only verifier. Single-operation entrypoint, manually runnable: sh verify.sh
# It never removes or creates a node.

MODDIR=$(dirname "$(readlink -f "$0" 2>/dev/null)")
ID=mtk-lk-preloader-guard
RUNDIR=/data/local/tmp/$ID
NODES=$RUNDIR.nodes
BN=/dev/block/by-name
mode=guard
[ -f "$MODDIR/mode" ] && read -r mode <"$MODDIR/mode"

printf 'mode=%s\n' "$mode"
recorded=0
present=0
missing=0

if [ -f "$NODES" ]; then
    while read -r kind path maj min; do
        [ "$kind" = node ] || continue
        recorded=$((recorded + 1))
        if [ -b "$path" ]; then
            present=$((present + 1))
            printf 'node PRESENT %s (%s:%s)\n' "$path" "$maj" "$min"
        else
            missing=$((missing + 1))
            printf 'node ABSENT %s (%s:%s)\n' "$path" "$maj" "$min"
        fi
    done <"$NODES"
fi

aliases=0
alias_missing=0
for alias in "$BN"/*; do
    [ -L "$alias" ] || continue
    name=${alias##*/}
    case "$(printf '%s' "$name" | tr 'A-Z' 'a-z')" in
        lk*|*preloader*)
            aliases=$((aliases + 1))
            real=$(readlink -f "$alias" 2>/dev/null)
            if [ -n "$real" ]; then
                printf 'alias PRESENT %s -> %s\n' "$alias" "$real"
            else
                alias_missing=$((alias_missing + 1))
                printf 'alias UNRESOLVED %s\n' "$alias"
            fi
            ;;
    esac
done

printf 'recorded_nodes=%s present_nodes=%s absent_nodes=%s preserved_aliases=%s unresolved_aliases=%s\n' "$recorded" "$present" "$missing" "$aliases" "$alias_missing"
if [ "$mode" = restore ]; then
    [ "$recorded" -gt 0 ] && [ "$present" -eq "$recorded" ] && [ "$alias_missing" -eq 0 ]
else
    { [ "$recorded" -eq 0 ] || [ "$present" -eq 0 ]; } && [ "$alias_missing" -eq 0 ]
fi
