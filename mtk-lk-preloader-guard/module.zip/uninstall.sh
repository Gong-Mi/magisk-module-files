#!/system/bin/sh
# Restore recorded final nodes; preserve every alias. Module removal may then proceed.
MODDIR=$(dirname "$(readlink -f "$0" 2>/dev/null)")
/system/bin/sh "$MODDIR/restore.sh"
exit $?
