#!/system/bin/sh
# Early guard pass. A restore-mode flag deliberately skips mutation.
MODDIR=$(dirname "$(readlink -f "$0" 2>/dev/null)")
mode=guard
[ -f "$MODDIR/mode" ] && read -r mode <"$MODDIR/mode"
if [ "$mode" = restore ]; then
    exit 0
fi
/system/bin/sh "$MODDIR/guard.sh"
exit $?
