#!/system/bin/sh
# Late-start second pass catches mapper/preloader nodes created after post-fs-data.
MODDIR=$(dirname "$(readlink -f "$0" 2>/dev/null)")
while [ "$(getprop sys.boot_completed)" != "1" ]; do sleep 1; done
mode=guard
[ -f "$MODDIR/mode" ] && read -r mode <"$MODDIR/mode"
[ "$mode" = restore ] && exit 0
/system/bin/sh "$MODDIR/guard.sh"
exit $?
