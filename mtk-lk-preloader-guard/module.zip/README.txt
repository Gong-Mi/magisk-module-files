MTK LK/Preloader Guard v3.1

Manual operation (root shell, no KSU app needed):
  cd /data/adb/modules*/mtk-lk-preloader-guard
  sh guard.sh     # remove only final real block nodes, keep all symlinks
  sh restore.sh   # recreate recorded nodes from major:minor, keep symlinks
  sh verify.sh    # read-only state report, exit code reflects state vs mode

KSU action button: toggles guard<->restore by calling the same scripts.
Mode flag: the file "mode" in the module dir contains guard or restore.
Before system OTA: run restore.sh (or tap action once) and require
verify.sh to show all recorded nodes PRESENT. After OTA, run guard.sh
to re-enable Android-side protection.

No script writes partition contents. No sdc/dm major/minor or model is hardcoded.
