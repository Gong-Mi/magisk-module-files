MTK LK/Preloader Guard v3

Guard mode (default):
- keeps /dev/block/by-name and /dev/block/mapper symlinks;
- resolves each lk*/preloader* alias with readlink -f;
- removes only the final real block device node;
- records its dynamic major:minor under /data/local/tmp/mtk-lk-preloader-guard.nodes.

The KSU action button toggles modes:
- guard -> restore: mknod recreates recorded final nodes, aliases are untouched;
- restore -> guard: removes only the final nodes again.

Before system OTA:
1. Tap the module action once and require restore mode plus verify output showing all recorded nodes PRESENT.
2. Run the OTA.
3. Tap the action again after OTA if Android-side LK/preloader protection should be re-enabled.

No script writes partition contents. No sdc/dm major/minor or model is hardcoded.
