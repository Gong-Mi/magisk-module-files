#!/system/bin/sh
# Restore only recorded final block nodes. Never deletes or recreates aliases.
# Single-operation entrypoint, manually runnable: sh restore.sh

MODDIR=$(dirname "$(readlink -f "$0" 2>/dev/null)")
ID=mtk-lk-preloader-guard
RUNDIR=/data/local/tmp/$ID
NODES=$RUNDIR.nodes
LOG=$RUNDIR.log

log() { printf '%s restore: %s\n' "$(date '+%m-%d %H:%M:%S')" "$*" >>"$LOG"; }

[ -f "$NODES" ] || { log "no node record; nothing to restore"; exit 1; }
restored=0
already=0
failed=0

while read -r kind path maj min; do
    [ "$kind" = node ] || continue
    [ -n "$path" ] || continue
    if [ -b "$path" ]; then
        already=$((already + 1))
        continue
    fi
    if mknod "$path" b "$maj" "$min" 2>/dev/null && [ -b "$path" ]; then
        chmod 660 "$path" 2>/dev/null
        chown root:root "$path" 2>/dev/null
        restored=$((restored + 1))
        log "restored final block node: $path ($maj:$min)"
    else
        failed=$((failed + 1))
        log "failed to restore final block node: $path ($maj:$min)"
    fi
done <"$NODES"

log "restore complete: restored=$restored already=$already failures=$failed"
[ "$failed" -eq 0 ]
