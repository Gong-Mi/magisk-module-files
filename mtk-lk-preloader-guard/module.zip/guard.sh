#!/system/bin/sh
# Guard: preserve every alias; remove only the final real block node.
# No partition contents are read or written.

MODDIR=$(dirname "$(readlink -f "$0" 2>/dev/null)")
ID=mtk-lk-preloader-guard
RUNDIR=/data/local/tmp/$ID
NODES=$RUNDIR.nodes
LOG=$RUNDIR.log
LOCK=$RUNDIR.lock
BN=/dev/block/by-name

log() { printf '%s guard: %s\n' "$(date '+%m-%d %H:%M:%S')" "$*" >>"$LOG"; }

mode=guard
[ -f "$MODDIR/mode" ] && read -r mode <"$MODDIR/mode"

mkdir -p /data/local/tmp "$RUNDIR" 2>/dev/null || exit 1
touch "$NODES" 2>/dev/null || { log "cannot create node record"; exit 1; }
[ "$mode" = restore ] && { log "restore mode, skip hide pass"; exit 0; }

if ! mkdir "$LOCK" 2>/dev/null; then
    log "another pass is running"
    exit 0
fi
trap 'rmdir "$LOCK" 2>/dev/null' EXIT

matched=0
removed=0
failed=0

for alias in "$BN"/*; do
    [ -L "$alias" ] || continue
    name=${alias##*/}
    case "$(printf '%s' "$name" | tr 'A-Z' 'a-z')" in
        lk*|*preloader*) ;;
        *) continue ;;
    esac

    matched=$((matched + 1))
    real=$(readlink -f "$alias" 2>/dev/null)
    if [ -z "$real" ] || [ ! -b "$real" ]; then
        log "alias preserved, final block node absent: $alias -> ${real:-<unresolved>}"
        continue
    fi

    mm=$(stat -c '%t %T' "$real" 2>/dev/null)
    set -- $mm
    maj=$(printf '%d' "0x${1:-}" 2>/dev/null)
    min=$(printf '%d' "0x${2:-}" 2>/dev/null)
    case "$maj:$min" in
        *[!0-9:]*|:*)
            log "cannot record major:minor: $alias -> $real ($mm)"
            failed=$((failed + 1))
            continue
            ;;
    esac

    if ! grep -F -q "node $real " "$NODES" 2>/dev/null; then
        printf 'node %s %s %s\n' "$real" "$maj" "$min" >>"$NODES" || {
            log "cannot persist record: $real"
            failed=$((failed + 1))
            continue
        }
    fi

    # Critical invariant: never rm "$alias". Only remove the final block node.
    if rm -f "$real" 2>/dev/null && [ ! -b "$real" ]; then
        removed=$((removed + 1))
        log "removed final block node, preserved alias: $alias -> $real ($maj:$min)"
    else
        failed=$((failed + 1))
        log "failed to remove final block node, alias preserved: $alias -> $real"
    fi
done

log "pass complete: aliases=$matched nodes_removed=$removed failures=$failed"
[ "$failed" -eq 0 ]
