#!/system/bin/sh
# KSU action: toggle between guard and restore mode.

MODDIR=$(dirname "$(readlink -f "$0" 2>/dev/null)")
ID=mtk-lk-preloader-guard
RUNDIR=/data/local/tmp/$ID
LOG=$RUNDIR.log
mode=guard
[ -f "$MODDIR/mode" ] && read -r mode <"$MODDIR/mode"
mkdir -p "$RUNDIR" 2>/dev/null

if [ "$mode" = guard ]; then
    if /system/bin/sh "$MODDIR/restore.sh"; then
        printf 'restore\n' >"$MODDIR/mode"
        printf '✅ restore mode: final block nodes recreated; aliases preserved\n'
    else
        printf '❌ restore failed; mode remains guard\n'
        exit 1
    fi
else
    if printf 'guard\n' >"$MODDIR/mode" && /system/bin/sh "$MODDIR/guard.sh"; then
        printf '✅ guard mode: final block nodes removed; aliases preserved\n'
    else
        printf '❌ guard pass failed\n'
        exit 1
    fi
fi
/system/bin/sh "$MODDIR/verify.sh"
