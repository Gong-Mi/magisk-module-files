#!/system/bin/sh
# KSU action button: thin wrapper. Each verb is also runnable by hand:
#   sh guard.sh / sh restore.sh / sh verify.sh
MODDIR=$(dirname "$(readlink -f "$0" 2>/dev/null)")
ID=mtk-lk-preloader-guard
RUNDIR=/data/local/tmp/$ID
mode=guard
[ -f "$MODDIR/mode" ] && read -r mode <"$MODDIR/mode"
mkdir -p "$RUNDIR" 2>/dev/null

if [ "$mode" = guard ]; then
    if /system/bin/sh "$MODDIR/restore.sh"; then
        printf 'restore\n' >"$MODDIR/mode"
        printf '✅ restore mode: final block nodes recreated; aliases preserved\n'
    else
        printf '❌ restore failed; mode remains guard\n'
        exit 1
    fi
else
    if printf 'guard\n' >"$MODDIR/mode" && /system/bin/sh "$MODDIR/guard.sh"; then
        printf '✅ guard mode: final block nodes removed; aliases preserved\n'
    else
        printf '❌ guard pass failed; mode is guard\n'
        exit 1
    fi
fi
exec /system/bin/sh "$MODDIR/verify.sh"
