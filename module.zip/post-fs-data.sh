#!/system/bin/sh
MODDIR=${0%/*}
FLAVOR=riru

log -p i -t "StorageIsolation" "post-fs-data ($FLAVOR)"

if [ "$ZYGISK_ENABLED" = false ] && [ "$FLAVOR" = "zygisk" ]; then
  log -p w -t "StorageIsolation" "Zygisk is disabled, skip zygisk-flavor script"
  exit 1
fi

if [ "$ZYGISK_ENABLED" = true ] && [ "$FLAVOR" = "riru" ]; then
  log -p w -t "StorageIsolation" "Zygisk is enabled, skip riru-flavor script"
  exit 1
fi

chmod 700 "$MODDIR"/starter
og -p w -t "StorageIsolation" "run $MODDIR/starter"
exec "$MODDIR/starter"
